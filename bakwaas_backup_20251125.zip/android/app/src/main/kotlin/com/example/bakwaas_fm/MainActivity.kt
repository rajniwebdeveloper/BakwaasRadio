// Deprecated MainActivity left for historical reasons.
// The active MainActivity is under the new package `com.bakwaas.fm`.

package com.example.bakwaas_fm

// Intentionally empty to avoid duplicate MainActivity definitions.
class MainActivity {}
