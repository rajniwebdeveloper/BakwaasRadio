package com.bakwaas.fm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {}
