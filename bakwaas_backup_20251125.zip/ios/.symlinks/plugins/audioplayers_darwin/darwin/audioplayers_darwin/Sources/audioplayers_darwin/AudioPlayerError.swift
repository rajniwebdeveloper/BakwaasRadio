enum AudioPlayerError: Error {
  case error(String)
  case warning(String)
}
