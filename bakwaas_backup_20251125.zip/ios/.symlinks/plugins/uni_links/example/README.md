# uni_links_example

Demonstrates how to use the uni_links plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
