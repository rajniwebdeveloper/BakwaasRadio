// Deprecated: moved to `lib/deprecated/series.dart` during cleanup.
// The backend implements series in JS and frontend did not reference
// the Dart model. The full original implementation is preserved in
// `lib/deprecated/series.dart`.

// No runtime code here.

