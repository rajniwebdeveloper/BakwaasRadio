// Deprecated: moved to `lib/deprecated/ui_helpers.dart` during cleanup.
// Keep this small shim here to avoid breaking any imports until you
// confirm removal. The full original implementation is preserved
// at `lib/deprecated/ui_helpers.dart`.

// No runtime code here.

