class AppData {
  // Demo playlists removed. Keep an empty list so UI can handle "no data".
  static final List<Map<String, dynamic>> playlists = [];
}
