These files were moved here as part of a safe cleanup.

- `ui_helpers.dart` — UI helper used for playlist UI. Was not imported anywhere in the app.
- `series.dart` — model for series. Backend uses a JS model; frontend did not reference this Dart model.

If you want these permanently removed, delete this folder. Kept here so nothing is lost.
